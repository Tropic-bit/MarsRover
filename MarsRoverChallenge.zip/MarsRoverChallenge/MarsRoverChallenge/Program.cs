﻿using System;

//Mission Object:
//Rover: Position and Location => (x,y,Z), Where Z in {N,E,W,S}
//Plateau:Grid of positions => (x,y,Z), where (0.0, N) => (x=0,y=0,Z=N)
//MaximumCoordinates => (maxX, maxY) =>(5 5) 
//Command: (aaaaaa) => a in (L,R,N) => (L=SpinLeft, R=SpinRight, M=MoveForward)
//Input = 5 lines:
// 1. Plateau Size: (5 5)
// 2. Array of RoverInstruction objects, where:
//    a. RoverPosition (first Line)
//    b. RoverCommand (second line)

//Expected Behaviour:
// 1. Rover should SpinLeft
// 2. Rover should SpinRight
// 3. Rover should StepForward
// 4. Rover should Move
namespace MarsRoverChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
