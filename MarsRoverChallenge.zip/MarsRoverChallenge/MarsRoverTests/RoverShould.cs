using System;
using Xunit;
using MarsRoverChallenge;

namespace MarsRoverTests
{
    public class RoverShould
    {
        [Fact]
        public void SpinLeft()
        {
            //organize
            RoverClass rover = new RoverClass("1 2 N");
            //act
            rover.SpinLeft();
            //assert
            Assert.Equal("W", rover.direction);

        }
        [Fact]
        public void SpinRight()
        {
            //organize
            RoverClass rover = new RoverClass("1 2 N");
            //act
            rover.SpinRight();
            //assert
            Assert.Equal("E", rover.direction);

        }
        [Fact]
        public void StepForward()
        {
            //organize
            RoverClass rover = new RoverClass("1 2 N");
            //act
            rover.StepForward();
            //assert
            Assert.Equal(3, rover.y);

        }
        [Fact]
        public void Move()
        {
            //organize
            RoverClass rover = new RoverClass("3 3 E");
            //act
            rover.Move("MMRMMRMRRM");
            //assert
            Assert.Equal("5 1 E", rover.x +" "+ rover.y +" "+ rover.direction);

        }
    }
}
